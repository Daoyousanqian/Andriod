package com.example.camera

import android.content.pm.PackageManager
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import kotlinx.android.synthetic.main.activity_main.*
//import java.util.jar.Manifest
import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Matrix
import android.net.Uri
import android.provider.MediaStore
import android.widget.Toast
import java.io.IOException
import java.net.URI
//import android.R
import android.graphics.BitmapFactory
import android.provider.MediaStore.Images.Media.getBitmap
import android.graphics.drawable.BitmapDrawable
import android.R.attr.bitmap
import android.provider.MediaStore.Images.Media.ORIENTATION
import android.view.Surface
import android.widget.TextView
import com.google.firebase.ml.vision.FirebaseVision
import com.google.firebase.ml.vision.common.FirebaseVisionImage
import com.google.firebase.ml.vision.text.FirebaseVisionTextRecognizer


//import activity_main





class MainActivity : AppCompatActivity() {


    private val REQUEST_IMAGE_CAPTURE: Int = 102
    private val IMAGE_CAPTURE_CODE: Int =1001;
    private val PERMISSION_CODE: Int = 1000;
    private val GALLERY : Int =101
    var image_uri: Uri? = null
    var rotation_times : Int = 0;
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val upload : Button = findViewById(R.id.upload)
        val imageView: ImageView = findViewById(R.id.imageView)
        val detect: Button = findViewById(R.id.detect)
        val showText: TextView = findViewById(R.id.showText)

        upload.setOnClickListener(){

            choosePhotoFromGallary()
           // showPictureDialog()

            //rotation_times = 0;
            //imageView.animate().rotation((90*rotation_times).toFloat())
        }
        detect.setOnClickListener {

            imageView.invalidate()
            val drawable = imageView.drawable as BitmapDrawable
            val bitmap = drawable.bitmap
            //val image = FirebaseVisionImage.fromBitmap(bitmap)
           // FirebaseVisionImage image = FirebaseVisionImage.fromBitmap(bitmap)
            //imageView.setImageBitmap(bitmap.rotate(90F))
            detectText(bitmap)

        }
    }

    private fun detectText(bitmap: Bitmap?){
        var text: String = ""
        var image: FirebaseVisionImage = FirebaseVisionImage.fromBitmap(bitmap!!)

        var detector: FirebaseVisionTextRecognizer = FirebaseVision.getInstance()
            .onDeviceTextRecognizer
        val result = detector.processImage(image)
            .addOnSuccessListener { firebaseVisionText ->

                showText.setText(firebaseVisionText.text)

            }
            .addOnFailureListener {

                Toast.makeText(this, "Extract Failed",Toast.LENGTH_SHORT).show()
            }

    }

    fun Bitmap.rotate(degrees: Float): Bitmap {
        val matrix = Matrix().apply { postRotate(degrees) }
        return Bitmap.createBitmap(this, 0, 0, width, height, matrix, true)
    }


    private fun showPictureDialog() {
        val pictureDialog = AlertDialog.Builder(this)
        pictureDialog.setTitle("Select Action")
        val pictureDialogItems = arrayOf("Camera", "Gallery","Cancel")
        pictureDialog.setItems(pictureDialogItems
        ) { dialog, which ->
            when (which) {
                1 -> choosePhotoFromGallary()
                0 -> takePhotoFromCamera()
                2 -> {}//pictureDialog.setCancelable(true)}
            }
        }
        pictureDialog.show()
    }
    fun takePhotoFromCamera(){

        if (Build.VERSION.SDK_INT >=Build.VERSION_CODES.M){
            if(checkSelfPermission(Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_DENIED||checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                == PackageManager.PERMISSION_DENIED){
                val permission = arrayOf(Manifest.permission.CAMERA,Manifest.permission.WRITE_EXTERNAL_STORAGE)
                //show popup to request permissions
                requestPermissions(permission,PERMISSION_CODE)

            }
            else {

                //permission granted
                openCamera()
            }

        }
        else{
            //os is marshmallow
            openCamera()
        }
    }

    fun choosePhotoFromGallary(){

        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        intent.type = "image/*"
        startActivityForResult(intent, GALLERY)

    }

    private fun openCamera() {

         val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        // startActivityForResult(cameraIntent, REQUEST_IMAGE_CAPTURE)
        if(cameraIntent.resolveActivity(packageManager)!=null){
            startActivityForResult(cameraIntent, REQUEST_IMAGE_CAPTURE)
        }

    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
       // super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        when(requestCode){

            PERMISSION_CODE ->{
                if(grantResults.size>0 && grantResults[0]==PackageManager.PERMISSION_GRANTED){
                    //permission already granted.
                    openCamera()
                }
                else{
                    //permission denied
                    Toast.makeText(this, "The permission is denied",Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == REQUEST_IMAGE_CAPTURE && data !=null ) {

            //Toast.makeText(this,"who am I ",Toast.LENGTH_SHORT).show()
            val imageBitmap = data.extras?.get("data") as Bitmap
            imageView.setImageBitmap(imageBitmap)

        }
        if(requestCode == GALLERY){
            if (data != null)
            {
                val contentURI = data!!.data
                try
                {
                    val bitmap = MediaStore.Images.Media.getBitmap(this.contentResolver, contentURI)
                   // val path = saveImage(bitmap)
                    //Toast.makeText(this@MainActivity, "Image Saved!", Toast.LENGTH_SHORT).show()
                    imageView.setImageBitmap(bitmap)

                }
                catch (e: IOException) {
                  //  e.printStackTrace()
                   // Toast.makeText(this@MainActivity, "Failed!", Toast.LENGTH_SHORT).show()
                }

            }
        }

    }
}
