package com.example.camera

import android.content.pm.PackageManager
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import kotlinx.android.synthetic.main.activity_main.*
//import java.util.jar.Manifest
import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Matrix
import android.net.Uri
import android.provider.MediaStore
import android.widget.Toast
import java.io.IOException
import java.net.URI
//import android.R
import android.graphics.BitmapFactory
import android.provider.MediaStore.Images.Media.getBitmap
import android.graphics.drawable.BitmapDrawable
import android.R.attr.bitmap
import android.provider.MediaStore.Images.Media.ORIENTATION
import android.view.Surface
import android.widget.TextView
import com.google.firebase.ml.vision.FirebaseVision
import com.google.firebase.ml.vision.common.FirebaseVisionImage
import com.google.firebase.ml.vision.text.FirebaseVisionTextRecognizer


//import activity_main





class MainActivity : AppCompatActivity() {


    private val REQUEST_IMAGE_CAPTURE: Int = 102
    private val IMAGE_CAPTURE_CODE: Int =1001;
    private val PERMISSION_CODE: Int = 1000;
    private val GALLERY : Int =101
    var image_uri: Uri? = null
    var rotation_times : Int = 0;
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val load : Button = findViewById(R.id.button)
        val imageView: ImageView = findViewById(R.id.showImage)

        val showText: TextView = findViewById(R.id.showAuthor)

        load.setOnClickListener(){

            var url =
        }

    }


}
